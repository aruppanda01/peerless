@include('users.layouts.head')
@include('users.layouts.header')
@include('users.layouts.sidebar')

@yield('content')
@extends('users.layouts.footer')
