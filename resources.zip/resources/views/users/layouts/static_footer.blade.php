<div class="app-wrapper-footer">
    <div class="app-footer">
        <div class="app-footer__inner">
            <div class="app-footer-right">
                <ul class="header-megamenu nav">
                    <li class="nav-item">
                        <a class="nav-link" style="color: #dd7478">
                            Copyright &copy; {{ date('Y') }} | All Right Reserved
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
