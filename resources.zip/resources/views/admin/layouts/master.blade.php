@include('admin.layouts.header')
@include('admin.layouts.sidebar')

@yield('content')

@include('admin.layouts.footer')