@extends('auth.layout.header')
@yield('content')
@extends('auth.layout.footer')