</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script type="text/javascript" src="{{ asset('frontend/js/wow.js') }}"></script>
<script>
    jQuery(document).ready(function($) {
        new WOW().init();
    });
</script>
</body>

</html>
